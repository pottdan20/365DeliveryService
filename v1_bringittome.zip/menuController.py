from backendDriver import good_id_by_name, menu_items


def getMenuItems():
    return menu_items()


def getItemIdByName(name):
    return good_id_by_name(name)



